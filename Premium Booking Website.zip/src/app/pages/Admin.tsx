import { useState, useMemo } from "react";
import { useNavigate } from "react-router";
import {
  LayoutDashboard, Package, ShoppingBag, Users, LogOut,
  Plus, Search, MoreVertical, TrendingUp, Eye, EyeOff,
  ChevronDown, ChevronUp, Check, X, Edit3, ToggleLeft, ToggleRight,
  IndianRupee, Star, Clock, MapPin, Filter, Menu,
} from "lucide-react";
import { useStore } from "../store";
import { mockUsers, type Package as Pkg, type Order, type User } from "../data";

const serif = { fontFamily: "'Playfair Display', serif" };
const sans = { fontFamily: "'DM Sans', sans-serif" };
const mono = { fontFamily: "'DM Mono', monospace" };

type AdminTab = "dashboard" | "packages" | "orders" | "users";

const STATUS_COLORS: Record<Order["status"], { bg: string; text: string; label: string }> = {
  confirmed: { bg: "#e6f4ec", text: "#1a7a3c", label: "Confirmed" },
  pending: { bg: "#fff8e6", text: "#8B6914", label: "Pending" },
  cancelled: { bg: "#fde8e8", text: "#b91c1c", label: "Cancelled" },
  completed: { bg: "#e8f0fe", text: "#1a5c8a", label: "Completed" },
};

// ─── Stat Card ────────────────────────────────────────────────────────────────

function StatCard({ label, value, sub, color, icon }: { label: string; value: string; sub: string; color: string; icon: React.ReactNode }) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-5 flex gap-4 items-start shadow-sm">
      <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0" style={{ background: color + "18" }}>
        <div style={{ color }}>{icon}</div>
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-xs font-semibold uppercase tracking-widest text-gray-400 mb-1" style={mono}>{label}</div>
        <div className="text-2xl font-bold text-gray-800" style={serif}>{value}</div>
        <div className="text-xs text-gray-400 mt-0.5" style={sans}>{sub}</div>
      </div>
    </div>
  );
}

// ─── Package Form Modal ───────────────────────────────────────────────────────

const emptyPkg: Omit<Pkg, "id"> = {
  title: "", places: "", duration: "", days: 7, nights: 6,
  price: 0, originalPrice: 0, rating: 4.5, reviews: 0,
  badge: "New", badgeColor: "#A2191B",
  image: "", category: "Heritage",
  highlights: ["", "", "", ""],
  maxGuests: 12, active: true,
};

function PackageModal({ pkg, onSave, onClose }: { pkg: Omit<Pkg, "id"> | Pkg; onSave: (p: any) => void; onClose: () => void }) {
  const [form, setForm] = useState({ ...pkg });
  const isEdit = "id" in pkg;

  const set = (k: string, v: any) => setForm((f) => ({ ...f, [k]: v }));
  const setHL = (i: number, v: string) => {
    const hl = [...form.highlights]; hl[i] = v; set("highlights", hl);
  };

  const handleSave = () => {
    if (!form.title || !form.places || !form.price) return;
    onSave({ ...form, highlights: form.highlights.filter(Boolean) });
  };

  const Input = ({ label, k, type = "text", placeholder = "" }: { label: string; k: string; type?: string; placeholder?: string }) => (
    <div>
      <label className="text-xs font-semibold uppercase tracking-widest text-gray-400 block mb-1.5" style={mono}>{label}</label>
      <input type={type} value={(form as any)[k]} onChange={(e) => set(k, type === "number" ? Number(e.target.value) : e.target.value)} placeholder={placeholder}
        className="w-full border-2 border-gray-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-[#A2191B] transition-colors" style={sans} />
    </div>
  );

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.6)" }}>
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col" style={{ maxHeight: "90vh" }}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h3 className="font-bold text-gray-800 text-lg" style={serif}>{isEdit ? "Edit Package" : "Add New Package"}</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors">
            <X className="w-4 h-4 text-gray-600" />
          </button>
        </div>
        <div className="overflow-y-auto p-6 flex flex-col gap-4" style={{ scrollbarWidth: "none" }}>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2"><Input label="Package Title" k="title" placeholder="Golden Triangle Heritage" /></div>
            <Input label="Places" k="places" placeholder="Delhi · Agra · Jaipur" />
            <Input label="Duration" k="duration" placeholder="7 Days / 6 Nights" />
            <Input label="Days" k="days" type="number" />
            <Input label="Nights" k="nights" type="number" />
            <Input label="Price per person (₹)" k="price" type="number" />
            <Input label="Original Price (₹)" k="originalPrice" type="number" />
            <Input label="Max Guests" k="maxGuests" type="number" />
            <div>
              <label className="text-xs font-semibold uppercase tracking-widest text-gray-400 block mb-1.5" style={mono}>Category</label>
              <select value={form.category} onChange={(e) => set("category", e.target.value)}
                className="w-full border-2 border-gray-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-[#A2191B] transition-colors bg-white" style={sans}>
                {["Heritage", "Nature", "Adventure", "Beach", "Cultural"].map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <Input label="Badge Text" k="badge" placeholder="Bestseller" />
            <div>
              <label className="text-xs font-semibold uppercase tracking-widest text-gray-400 block mb-1.5" style={mono}>Badge Color</label>
              <div className="flex gap-2 items-center">
                <input type="color" value={form.badgeColor} onChange={(e) => set("badgeColor", e.target.value)} className="w-10 h-10 rounded-lg border-2 border-gray-200 cursor-pointer" />
                <span className="text-sm text-gray-500 font-mono">{form.badgeColor}</span>
              </div>
            </div>
            <div className="sm:col-span-2"><Input label="Image URL" k="image" placeholder="https://images.unsplash.com/..." /></div>
            {form.image && (
              <div className="sm:col-span-2">
                <div className="h-32 rounded-xl overflow-hidden bg-gray-100">
                  <img src={form.image} alt="preview" className="w-full h-full object-cover" onError={(e) => (e.currentTarget.style.display = "none")} />
                </div>
              </div>
            )}
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-widest text-gray-400 block mb-2" style={mono}>Highlights (up to 4)</label>
            <div className="flex flex-col gap-2">
              {[0, 1, 2, 3].map((i) => (
                <input key={i} value={form.highlights[i] ?? ""} onChange={(e) => setHL(i, e.target.value)} placeholder={`Highlight ${i + 1}`}
                  className="w-full border-2 border-gray-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-[#A2191B] transition-colors" style={sans} />
              ))}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => set("active", !form.active)} className="flex items-center gap-2 text-sm font-medium" style={sans}>
              {form.active ? <ToggleRight className="w-6 h-6" style={{ color: "#1a7a3c" }} /> : <ToggleLeft className="w-6 h-6 text-gray-400" />}
              <span style={{ color: form.active ? "#1a7a3c" : "#9ca3af" }}>{form.active ? "Active" : "Inactive"}</span>
            </button>
          </div>
        </div>
        <div className="flex gap-3 px-6 py-4 border-t border-gray-100">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border-2 border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50 transition-colors" style={sans}>Cancel</button>
          <button onClick={handleSave} className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white transition-all hover:opacity-90" style={{ background: "linear-gradient(135deg,#A2191B,#FA0301)", ...sans }}>
            {isEdit ? "Save Changes" : "Add Package"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Admin Page ───────────────────────────────────────────────────────────────

export default function Admin() {
  const navigate = useNavigate();
  const { packages, orders, addPackage, updatePackage, togglePackageActive, updateOrderStatus } = useStore();
  const users: User[] = mockUsers;

  const [tab, setTab] = useState<AdminTab>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [pkgSearch, setPkgSearch] = useState("");
  const [orderSearch, setOrderSearch] = useState("");
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>("all");
  const [userSearch, setUserSearch] = useState("");
  const [showPkgModal, setShowPkgModal] = useState(false);
  const [editingPkg, setEditingPkg] = useState<Pkg | null>(null);
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);

  // Auth gate
  const [authed, setAuthed] = useState(false);
  const [adminPass, setAdminPass] = useState("");
  const [authError, setAuthError] = useState("");

  const handleAuth = () => {
    if (adminPass === "admin123") { setAuthed(true); setAuthError(""); }
    else setAuthError("Incorrect password. Hint: admin123");
  };

  if (!authed) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "linear-gradient(135deg,#1a0a0a,#3a1010)" }}>
        <div className="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md mx-4">
          <div className="flex flex-col items-center mb-8">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4" style={{ background: "#A2191B" }}>
              <span className="text-white font-black text-xl" style={serif}>B</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-800" style={serif}>Admin Panel</h1>
            <p className="text-gray-400 text-sm mt-1" style={sans}>BookMyIndia · Secure Access</p>
          </div>
          <div className="flex flex-col gap-3">
            <div>
              <label className="text-xs font-semibold uppercase tracking-widest text-gray-400 block mb-1.5" style={mono}>Password</label>
              <input type="password" value={adminPass} onChange={(e) => setAdminPass(e.target.value)} placeholder="Enter admin password"
                onKeyDown={(e) => e.key === "Enter" && handleAuth()}
                className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#A2191B] transition-colors" style={sans} />
              {authError && <p className="text-red-500 text-xs mt-1.5" style={sans}>{authError}</p>}
            </div>
            <button onClick={handleAuth} className="w-full py-3 rounded-xl text-white font-bold text-sm mt-2 transition-all hover:opacity-90" style={{ background: "linear-gradient(135deg,#A2191B,#FA0301)", ...sans }}>
              Sign In →
            </button>
            <button onClick={() => navigate("/")} className="text-center text-xs text-gray-400 hover:text-gray-600 mt-1 transition-colors" style={sans}>← Back to website</button>
          </div>
        </div>
      </div>
    );
  }

  // ── Stats ──
  const totalRevenue = orders.reduce((s, o) => s + o.total, 0);
  const confirmedOrders = orders.filter((o) => o.status === "confirmed").length;
  const activePackages = packages.filter((p) => p.active).length;
  const totalGuests = orders.reduce((s, o) => s + o.guests, 0);

  // ── Filters ──
  const filteredPkgs = useMemo(() => packages.filter((p) => !pkgSearch || p.title.toLowerCase().includes(pkgSearch.toLowerCase()) || p.places.toLowerCase().includes(pkgSearch.toLowerCase())), [packages, pkgSearch]);
  const filteredOrders = useMemo(() => orders.filter((o) => {
    const matchSearch = !orderSearch || o.packageTitle.toLowerCase().includes(orderSearch.toLowerCase()) || o.orderId.toLowerCase().includes(orderSearch.toLowerCase()) || o.traveller.name.toLowerCase().includes(orderSearch.toLowerCase());
    const matchStatus = orderStatusFilter === "all" || o.status === orderStatusFilter;
    return matchSearch && matchStatus;
  }), [orders, orderSearch, orderStatusFilter]);
  const filteredUsers = useMemo(() => users.filter((u) => !userSearch || u.name.toLowerCase().includes(userSearch.toLowerCase()) || u.email.toLowerCase().includes(userSearch.toLowerCase())), [users, userSearch]);

  const handleSavePkg = (p: any) => {
    if (editingPkg) { updatePackage({ ...p, id: editingPkg.id }); }
    else { addPackage({ ...p, id: Date.now() }); }
    setShowPkgModal(false); setEditingPkg(null);
  };

  const navItems: { id: AdminTab; icon: React.ReactNode; label: string }[] = [
    { id: "dashboard", icon: <LayoutDashboard className="w-4 h-4" />, label: "Dashboard" },
    { id: "packages", icon: <Package className="w-4 h-4" />, label: "Packages" },
    { id: "orders", icon: <ShoppingBag className="w-4 h-4" />, label: "Orders" },
    { id: "users", icon: <Users className="w-4 h-4" />, label: "Users" },
  ];

  const Sidebar = ({ mobile = false }: { mobile?: boolean }) => (
    <aside className={mobile ? "w-56 bg-[#1a0a0a] h-full flex flex-col" : "w-56 bg-[#1a0a0a] min-h-screen flex flex-col"}>
      <div className="px-5 py-5 border-b border-white/8">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: "#A2191B" }}>
            <span className="text-white font-black text-sm" style={serif}>B</span>
          </div>
          <div>
            <div className="text-white text-sm font-bold leading-none" style={serif}>BookMyIndia</div>
            <div className="text-white/30 text-[10px] mt-0.5" style={mono}>ADMIN PANEL</div>
          </div>
        </div>
      </div>
      <nav className="flex-1 px-3 py-4 flex flex-col gap-1">
        {navItems.map((item) => (
          <button key={item.id} onClick={() => { setTab(item.id); setSidebarOpen(false); }}
            className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all w-full text-left ${tab === item.id ? "text-white" : "text-white/40 hover:text-white/70 hover:bg-white/5"}`}
            style={{ background: tab === item.id ? "rgba(255,255,255,0.08)" : "transparent", ...sans }}>
            {item.icon}{item.label}
            {tab === item.id && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#FA0301]" />}
          </button>
        ))}
      </nav>
      <div className="px-3 py-4 border-t border-white/8">
        <button onClick={() => navigate("/")}
          className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-sm text-white/40 hover:text-white/70 transition-colors w-full" style={sans}>
          <LogOut className="w-4 h-4" />Exit Admin
        </button>
      </div>
    </aside>
  );

  return (
    <div className="flex min-h-screen" style={{ background: "#f7f4f0" }}>
      {/* Desktop sidebar */}
      <div className="hidden lg:block shrink-0"><Sidebar /></div>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="w-56"><Sidebar mobile /></div>
          <div className="flex-1 bg-black/50" onClick={() => setSidebarOpen(false)} />
        </div>
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="bg-white border-b border-gray-100 px-5 lg:px-8 py-4 flex items-center gap-4 shrink-0">
          <button className="lg:hidden" onClick={() => setSidebarOpen(true)}>
            <Menu className="w-5 h-5 text-gray-600" />
          </button>
          <h2 className="font-bold text-gray-800 text-lg" style={serif}>
            {tab === "dashboard" && "Dashboard"}
            {tab === "packages" && "Package Management"}
            {tab === "orders" && "Orders Management"}
            {tab === "users" && "User Management"}
          </h2>
          <div className="ml-auto flex items-center gap-3">
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ background: "#A2191B", ...mono }}>A</div>
            <span className="text-sm font-medium text-gray-700 hidden sm:block" style={sans}>Admin</span>
          </div>
        </header>

        <main className="flex-1 px-5 lg:px-8 py-7 overflow-auto">

          {/* ─── Dashboard ──────────────────────────────────────────────────── */}
          {tab === "dashboard" && (
            <div className="flex flex-col gap-7">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard label="Total Revenue" value={`₹${(totalRevenue / 100000).toFixed(1)}L`} sub={`${orders.length} bookings`} color="#A2191B" icon={<IndianRupee className="w-5 h-5" />} />
                <StatCard label="Active Packages" value={String(activePackages)} sub={`${packages.length} total`} color="#1a7a3c" icon={<Package className="w-5 h-5" />} />
                <StatCard label="Confirmed Orders" value={String(confirmedOrders)} sub="this season" color="#1a5c8a" icon={<ShoppingBag className="w-5 h-5" />} />
                <StatCard label="Total Guests" value={String(totalGuests)} sub="across all bookings" color="#8B6914" icon={<Users className="w-5 h-5" />} />
              </div>

              {/* Recent orders */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
                  <h3 className="font-bold text-gray-800" style={serif}>Recent Orders</h3>
                  <button onClick={() => setTab("orders")} className="text-xs text-[#A2191B] font-semibold hover:underline" style={sans}>View all →</button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm" style={sans}>
                    <thead><tr className="bg-gray-50 text-gray-400 text-xs uppercase tracking-widest" style={mono}>
                      <th className="text-left px-6 py-3">Order ID</th>
                      <th className="text-left px-6 py-3 hidden sm:table-cell">Package</th>
                      <th className="text-left px-6 py-3 hidden md:table-cell">Traveller</th>
                      <th className="text-right px-6 py-3">Amount</th>
                      <th className="text-left px-6 py-3">Status</th>
                    </tr></thead>
                    <tbody>
                      {orders.slice(0, 5).map((o) => {
                        const s = STATUS_COLORS[o.status];
                        return (
                          <tr key={o.orderId} className="border-t border-gray-50 hover:bg-gray-50/60 transition-colors">
                            <td className="px-6 py-3.5 font-mono text-[11px] text-gray-500">{o.orderId}</td>
                            <td className="px-6 py-3.5 hidden sm:table-cell">
                              <div className="font-medium text-gray-700 truncate max-w-[160px]">{o.packageTitle}</div>
                            </td>
                            <td className="px-6 py-3.5 hidden md:table-cell text-gray-500">{o.traveller.name}</td>
                            <td className="px-6 py-3.5 text-right font-semibold text-gray-800">₹{o.total.toLocaleString()}</td>
                            <td className="px-6 py-3.5">
                              <span className="text-xs font-semibold px-2.5 py-1 rounded-full" style={{ background: s.bg, color: s.text, ...mono }}>{s.label}</span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Top packages */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
                  <h3 className="font-bold text-gray-800" style={serif}>Top Packages</h3>
                  <button onClick={() => setTab("packages")} className="text-xs text-[#A2191B] font-semibold hover:underline" style={sans}>Manage →</button>
                </div>
                <div className="flex flex-col divide-y divide-gray-50">
                  {packages.filter((p) => p.active).slice(0, 4).map((p) => (
                    <div key={p.id} className="flex items-center gap-4 px-6 py-4 hover:bg-gray-50/60 transition-colors">
                      <div className="w-12 h-12 rounded-xl overflow-hidden shrink-0 bg-gray-100">
                        <img src={p.image} alt={p.title} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-gray-700 text-sm truncate" style={serif}>{p.title}</div>
                        <div className="text-xs text-gray-400 flex items-center gap-2 mt-0.5" style={sans}>
                          <MapPin className="w-3 h-3 shrink-0" />{p.places}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="font-bold text-gray-800 text-sm" style={mono}>₹{p.price.toLocaleString()}</div>
                        <div className="text-xs text-gray-400 flex items-center gap-1 justify-end mt-0.5" style={sans}>
                          <Star className="w-3 h-3 fill-[#FCBD70] stroke-[#FCBD70]" />{p.rating}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ─── Packages ───────────────────────────────────────────────────── */}
          {tab === "packages" && (
            <div className="flex flex-col gap-5">
              <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
                <div className="flex-1 flex items-center gap-2 bg-white border-2 border-gray-200 rounded-xl px-4 py-2.5 focus-within:border-[#A2191B] transition-colors">
                  <Search className="w-4 h-4 text-gray-400 shrink-0" />
                  <input value={pkgSearch} onChange={(e) => setPkgSearch(e.target.value)} placeholder="Search packages…"
                    className="flex-1 outline-none text-sm text-gray-700 bg-transparent" style={sans} />
                </div>
                <button onClick={() => { setEditingPkg(null); setShowPkgModal(true); }}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-white text-sm font-semibold transition-all hover:opacity-90 shrink-0"
                  style={{ background: "linear-gradient(135deg,#A2191B,#FA0301)", ...sans }}>
                  <Plus className="w-4 h-4" />Add Package
                </button>
              </div>

              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm" style={sans}>
                    <thead><tr className="bg-gray-50 text-gray-400 text-xs uppercase tracking-widest" style={mono}>
                      <th className="text-left px-5 py-3">Package</th>
                      <th className="text-left px-5 py-3 hidden md:table-cell">Category</th>
                      <th className="text-right px-5 py-3">Price</th>
                      <th className="text-left px-5 py-3 hidden sm:table-cell">Duration</th>
                      <th className="text-left px-5 py-3">Status</th>
                      <th className="text-right px-5 py-3">Actions</th>
                    </tr></thead>
                    <tbody>
                      {filteredPkgs.map((p) => (
                        <tr key={p.id} className="border-t border-gray-50 hover:bg-gray-50/60 transition-colors">
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-lg overflow-hidden bg-gray-100 shrink-0">
                                <img src={p.image} alt={p.title} className="w-full h-full object-cover" />
                              </div>
                              <div>
                                <div className="font-semibold text-gray-700 text-sm leading-tight">{p.title}</div>
                                <div className="text-xs text-gray-400 mt-0.5">{p.places}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-4 hidden md:table-cell">
                            <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "#f5f0eb", color: "#7a5c5c" }}>{p.category}</span>
                          </td>
                          <td className="px-5 py-4 text-right font-semibold text-gray-800" style={mono}>₹{p.price.toLocaleString()}</td>
                          <td className="px-5 py-4 hidden sm:table-cell text-gray-500 text-xs">{p.duration}</td>
                          <td className="px-5 py-4">
                            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${p.active ? "text-[#1a7a3c]" : "text-gray-400"}`}
                              style={{ background: p.active ? "#e6f4ec" : "#f3f4f6", ...mono }}>
                              {p.active ? "Active" : "Inactive"}
                            </span>
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex items-center justify-end gap-1">
                              <button onClick={() => { setEditingPkg(p); setShowPkgModal(true); }}
                                className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-blue-50 hover:text-blue-600 flex items-center justify-center transition-colors" title="Edit">
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button onClick={() => togglePackageActive(p.id)}
                                className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center transition-colors hover:bg-amber-50 hover:text-amber-600" title={p.active ? "Deactivate" : "Activate"}>
                                {p.active ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                      {filteredPkgs.length === 0 && (
                        <tr><td colSpan={6} className="px-5 py-10 text-center text-gray-400 text-sm" style={sans}>No packages found.</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ─── Orders ─────────────────────────────────────────────────────── */}
          {tab === "orders" && (
            <div className="flex flex-col gap-5">
              <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
                <div className="flex-1 flex items-center gap-2 bg-white border-2 border-gray-200 rounded-xl px-4 py-2.5 focus-within:border-[#A2191B] transition-colors">
                  <Search className="w-4 h-4 text-gray-400 shrink-0" />
                  <input value={orderSearch} onChange={(e) => setOrderSearch(e.target.value)} placeholder="Search by order ID, package or traveller…"
                    className="flex-1 outline-none text-sm text-gray-700 bg-transparent" style={sans} />
                </div>
                <div className="flex items-center gap-2 bg-white border-2 border-gray-200 rounded-xl px-4 py-2.5">
                  <Filter className="w-4 h-4 text-gray-400" />
                  <select value={orderStatusFilter} onChange={(e) => setOrderStatusFilter(e.target.value)}
                    className="outline-none text-sm text-gray-600 bg-transparent" style={sans}>
                    <option value="all">All Status</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="pending">Pending</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-col gap-3">
                {filteredOrders.map((o) => {
                  const s = STATUS_COLORS[o.status];
                  const isOpen = expandedOrder === o.orderId;
                  return (
                    <div key={o.orderId} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                      <div
                        className="flex flex-wrap gap-3 items-center px-5 py-4 cursor-pointer hover:bg-gray-50/60 transition-colors"
                        onClick={() => setExpandedOrder(isOpen ? null : o.orderId)}
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-mono text-[11px] text-gray-400">{o.orderId}</span>
                            <span className="text-xs px-2 py-0.5 rounded-full font-semibold" style={{ background: s.bg, color: s.text, ...mono }}>{s.label}</span>
                          </div>
                          <div className="font-semibold text-gray-700 mt-0.5 text-sm" style={serif}>{o.packageTitle}</div>
                          <div className="text-xs text-gray-400 mt-0.5" style={sans}>{o.traveller.name} · {o.travelDate} · {o.guests} guests</div>
                        </div>
                        <div className="flex items-center gap-3 shrink-0">
                          <div className="text-right">
                            <div className="font-bold text-gray-800" style={{ ...mono, fontSize: "14px" }}>₹{o.total.toLocaleString()}</div>
                            <div className="text-xs text-gray-400" style={sans}>{o.paymentMethod}</div>
                          </div>
                          {isOpen ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                        </div>
                      </div>

                      {isOpen && (
                        <div className="px-5 pb-5 border-t border-gray-50">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                            <div>
                              <div className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-2" style={mono}>Traveller Details</div>
                              {[
                                ["Name", o.traveller.name], ["Email", o.traveller.email],
                                ["Phone", o.traveller.phone], ["City", o.traveller.city],
                              ].map(([k, v]) => (
                                <div key={k} className="flex gap-2 text-sm mb-1.5" style={sans}>
                                  <span className="text-gray-400 w-14 shrink-0">{k}</span>
                                  <span className="text-gray-700 font-medium">{v}</span>
                                </div>
                              ))}
                            </div>
                            <div>
                              <div className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-2" style={mono}>Payment Details</div>
                              {[
                                ["Method", o.paymentMethod], ["ID", o.paymentId],
                                ["Subtotal", `₹${o.subtotal.toLocaleString()}`],
                                o.discount > 0 ? ["Discount", `−₹${o.discount.toLocaleString()}`] : null,
                                ["GST", `₹${o.taxes.toLocaleString()}`],
                                ["Total", `₹${o.total.toLocaleString()}`],
                              ].filter(Boolean).map(([k, v]) => (
                                <div key={k!} className="flex gap-2 text-sm mb-1.5" style={sans}>
                                  <span className="text-gray-400 w-16 shrink-0">{k}</span>
                                  <span className={`font-medium ${k === "Total" ? "text-[#A2191B] font-bold" : k === "Discount" ? "text-green-600" : "text-gray-700"}`}>{v}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="mt-4 pt-4 border-t border-gray-50">
                            <div className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-2" style={mono}>Update Status</div>
                            <div className="flex flex-wrap gap-2">
                              {(["confirmed", "pending", "completed", "cancelled"] as Order["status"][]).map((st) => {
                                const sc = STATUS_COLORS[st];
                                return (
                                  <button key={st} onClick={() => updateOrderStatus(o.orderId, st)}
                                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${o.status === st ? "border-transparent" : "border-gray-200 hover:border-gray-300"}`}
                                    style={{ background: o.status === st ? sc.bg : "white", color: o.status === st ? sc.text : "#9ca3af", ...sans }}>
                                    {o.status === st && <Check className="w-3 h-3" />}
                                    {sc.label}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
                {filteredOrders.length === 0 && (
                  <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center text-gray-400 text-sm" style={sans}>No orders found.</div>
                )}
              </div>
            </div>
          )}

          {/* ─── Users ──────────────────────────────────────────────────────── */}
          {tab === "users" && (
            <div className="flex flex-col gap-5">
              <div className="flex items-center gap-2 bg-white border-2 border-gray-200 rounded-xl px-4 py-2.5 focus-within:border-[#A2191B] transition-colors max-w-md">
                <Search className="w-4 h-4 text-gray-400 shrink-0" />
                <input value={userSearch} onChange={(e) => setUserSearch(e.target.value)} placeholder="Search users by name or email…"
                  className="flex-1 outline-none text-sm text-gray-700 bg-transparent" style={sans} />
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard label="Total Users" value={String(users.length)} sub="registered" color="#1a5c8a" icon={<Users className="w-5 h-5" />} />
                <StatCard label="Active Users" value={String(users.filter((u) => u.status === "active").length)} sub="last 90 days" color="#1a7a3c" icon={<TrendingUp className="w-5 h-5" />} />
                <StatCard label="Avg Spend" value={`₹${Math.round(users.reduce((s, u) => s + u.totalSpent, 0) / users.filter((u) => u.totalBookings > 0).length / 1000)}K`} sub="per active user" color="#8B6914" icon={<IndianRupee className="w-5 h-5" />} />
                <StatCard label="Avg Bookings" value={(users.reduce((s, u) => s + u.totalBookings, 0) / users.length).toFixed(1)} sub="per user" color="#A2191B" icon={<ShoppingBag className="w-5 h-5" />} />
              </div>

              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm" style={sans}>
                    <thead><tr className="bg-gray-50 text-gray-400 text-xs uppercase tracking-widest" style={mono}>
                      <th className="text-left px-5 py-3">User</th>
                      <th className="text-left px-5 py-3 hidden md:table-cell">Contact</th>
                      <th className="text-left px-5 py-3 hidden sm:table-cell">City</th>
                      <th className="text-right px-5 py-3">Bookings</th>
                      <th className="text-right px-5 py-3 hidden sm:table-cell">Spent</th>
                      <th className="text-left px-5 py-3">Status</th>
                      <th className="text-left px-5 py-3 hidden lg:table-cell">Joined</th>
                    </tr></thead>
                    <tbody>
                      {filteredUsers.map((u) => (
                        <tr key={u.id} className="border-t border-gray-50 hover:bg-gray-50/60 transition-colors">
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-full overflow-hidden bg-gray-100 shrink-0">
                                <img src={u.avatar} alt={u.name} className="w-full h-full object-cover" />
                              </div>
                              <div>
                                <div className="font-semibold text-gray-700 text-sm">{u.name}</div>
                                <div className="text-xs text-gray-400 font-mono">{u.id}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-4 hidden md:table-cell">
                            <div className="text-xs text-gray-600">{u.email}</div>
                            <div className="text-xs text-gray-400 mt-0.5">{u.phone}</div>
                          </td>
                          <td className="px-5 py-4 hidden sm:table-cell text-gray-500 text-xs">{u.city}</td>
                          <td className="px-5 py-4 text-right font-semibold text-gray-700" style={mono}>{u.totalBookings}</td>
                          <td className="px-5 py-4 text-right font-semibold text-gray-700 hidden sm:table-cell" style={mono}>
                            {u.totalSpent > 0 ? `₹${(u.totalSpent / 1000).toFixed(0)}K` : "—"}
                          </td>
                          <td className="px-5 py-4">
                            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${u.status === "active" ? "text-[#1a7a3c]" : "text-gray-400"}`}
                              style={{ background: u.status === "active" ? "#e6f4ec" : "#f3f4f6", ...mono }}>
                              {u.status === "active" ? "Active" : "Inactive"}
                            </span>
                          </td>
                          <td className="px-5 py-4 hidden lg:table-cell text-xs text-gray-400" style={mono}>
                            {new Date(u.joinedAt).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}
                          </td>
                        </tr>
                      ))}
                      {filteredUsers.length === 0 && (
                        <tr><td colSpan={7} className="px-5 py-10 text-center text-gray-400 text-sm" style={sans}>No users found.</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* Package modal */}
      {showPkgModal && (
        <PackageModal
          pkg={editingPkg ?? emptyPkg}
          onSave={handleSavePkg}
          onClose={() => { setShowPkgModal(false); setEditingPkg(null); }}
        />
      )}
    </div>
  );
}
