import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router";
import { MapPin, Menu, X, ShoppingBag } from "lucide-react";
import { useStore } from "../store";

const serif = { fontFamily: "'Playfair Display', serif" };
const sans = { fontFamily: "'DM Sans', sans-serif" };

export default function Nav({ transparent = false }: { transparent?: boolean }) {
  const [scrolled, setScrolled] = useState(!transparent);
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const { orders } = useStore();
  const upcomingCount = orders.filter((o) => o.status === "confirmed").length;

  useEffect(() => {
    if (!transparent) { setScrolled(true); return; }
    const h = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", h);
    return () => window.removeEventListener("scroll", h);
  }, [transparent]);

  const isActive = (path: string) => location.pathname.startsWith(path);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-400 ${
        scrolled
          ? "bg-white/96 backdrop-blur-md shadow-sm border-b border-[#A2191B]/10"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-5 lg:px-10 flex items-center justify-between h-16">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg,#A2191B,#FA0301)" }}>
            <MapPin className="w-4 h-4 text-white" strokeWidth={2.5} />
          </div>
          <span className="font-bold text-lg" style={{ ...serif, color: scrolled ? "#A2191B" : "#fff" }}>
            BookMy<span style={{ color: "#FCBD70" }}>India</span>
          </span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-7">
          {[
            { label: "Packages", to: "/" },
            { label: "Destinations", to: "/" },
            { label: "Blog", to: "/" },
          ].map(({ label, to }) => (
            <Link
              key={label}
              to={to}
              className={`text-sm font-medium transition-colors hover:opacity-75 ${scrolled ? "text-[#1a0a0a]" : "text-white/90"}`}
              style={sans}
            >
              {label}
            </Link>
          ))}
        </div>

        {/* CTA row */}
        <div className="hidden md:flex items-center gap-3">
          <Link
            to="/my-orders"
            className={`relative flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-full transition-all ${
              isActive("/my-orders")
                ? "bg-[#A2191B] text-white"
                : scrolled
                ? "text-[#A2191B] border border-[#A2191B]/30 hover:bg-[#A2191B]/5"
                : "text-white border border-white/30 hover:bg-white/10"
            }`}
            style={sans}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            My Orders
            {upcomingCount > 0 && (
              <span className="w-4 h-4 rounded-full text-[10px] font-bold flex items-center justify-center" style={{ background: "#FCBD70", color: "#1a0a0a" }}>
                {upcomingCount}
              </span>
            )}
          </Link>
          <Link
            to="/"
            className="px-5 py-2 rounded-full text-sm font-semibold text-white hover:scale-105 transition-transform"
            style={{ background: "linear-gradient(135deg,#A2191B,#FA0301)", ...sans }}
          >
            Plan Trip
          </Link>
        </div>

        {/* Mobile toggle */}
        <button className={`md:hidden p-2 ${scrolled ? "text-[#1a0a0a]" : "text-white"}`} onClick={() => setOpen(!open)}>
          {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-white border-t border-[#A2191B]/10 px-5 py-4 flex flex-col gap-3">
          {[
            { label: "Packages", to: "/" },
            { label: "My Orders", to: "/my-orders" },
          ].map(({ label, to }) => (
            <Link key={label} to={to} className="text-sm text-[#1a0a0a] py-1 font-medium" style={sans} onClick={() => setOpen(false)}>
              {label}
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
}
