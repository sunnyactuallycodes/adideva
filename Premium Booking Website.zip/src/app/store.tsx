import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import { mockOrders, initialPackages, type Order, type Package } from "./data";

interface StoreCtx {
  orders: Order[];
  addOrder: (o: Order) => void;
  updateOrderStatus: (orderId: string, status: Order["status"]) => void;
  packages: Package[];
  addPackage: (p: Package) => void;
  updatePackage: (p: Package) => void;
  togglePackageActive: (id: number) => void;
}

const Ctx = createContext<StoreCtx | null>(null);
const LS_ORDERS = "bmi_orders";
const LS_PACKAGES = "bmi_packages";

export function StoreProvider({ children }: { children: ReactNode }) {
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const s = localStorage.getItem(LS_ORDERS);
      return s ? JSON.parse(s) : mockOrders;
    } catch { return mockOrders; }
  });

  const [packages, setPackages] = useState<Package[]>(() => {
    try {
      const s = localStorage.getItem(LS_PACKAGES);
      return s ? JSON.parse(s) : initialPackages;
    } catch { return initialPackages; }
  });

  useEffect(() => { localStorage.setItem(LS_ORDERS, JSON.stringify(orders)); }, [orders]);
  useEffect(() => { localStorage.setItem(LS_PACKAGES, JSON.stringify(packages)); }, [packages]);

  const addOrder = (o: Order) => setOrders((p) => [o, ...p]);

  const updateOrderStatus = (orderId: string, status: Order["status"]) =>
    setOrders((p) => p.map((o) => (o.orderId === orderId ? { ...o, status } : o)));

  const addPackage = (p: Package) => setPackages((prev) => [...prev, p]);

  const updatePackage = (p: Package) =>
    setPackages((prev) => prev.map((x) => (x.id === p.id ? p : x)));

  const togglePackageActive = (id: number) =>
    setPackages((prev) => prev.map((x) => (x.id === id ? { ...x, active: !x.active } : x)));

  return (
    <Ctx.Provider value={{ orders, addOrder, updateOrderStatus, packages, addPackage, updatePackage, togglePackageActive }}>
      {children}
    </Ctx.Provider>
  );
}

export function useStore() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore must be inside StoreProvider");
  return ctx;
}
