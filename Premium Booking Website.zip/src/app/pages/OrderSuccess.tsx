import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router";
import { Check, MapPin, Calendar, Users, Clock, Download, ShoppingBag, ArrowRight, Phone, Mail, Share2 } from "lucide-react";
import Nav from "../components/Nav";
import type { Order } from "../data";

const serif = { fontFamily: "'Playfair Display', serif" };
const sans = { fontFamily: "'DM Sans', sans-serif" };
const mono = { fontFamily: "'DM Mono', monospace" };

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
}

export default function OrderSuccess() {
  const location = useLocation();
  const navigate = useNavigate();
  const order = (location.state as { order: Order } | null)?.order;

  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    import("canvas-confetti").then((mod: any) => {
      const confetti = mod.default;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const fire = (pO: number, opts: any) => confetti({ ...opts, particleCount: Math.floor(200 * pO), spread: 26 * pO });
      const burst = () => {
        fire(0.25, { angle: 55, origin: { x: 0 } });
        fire(0.2, { angle: 60, origin: { x: 0 } });
        fire(0.35, { angle: 115, origin: { x: 1 } });
        fire(0.1, { angle: 120, origin: { x: 1 } });
        fire(0.1, { angle: 90, origin: { x: 0.5 }, colors: ["#A2191B", "#FA0301", "#FCBD70", "#ffffff"] });
      };
      burst();
      setTimeout(burst, 600);
    });
  }, []);

  if (!order) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#faf8f5" }}>
        <div className="text-center">
          <p className="text-[#7a5c5c] mb-4" style={sans}>No booking found.</p>
          <button onClick={() => navigate("/")} className="px-6 py-3 rounded-full text-white font-semibold" style={{ background: "#A2191B", ...sans }}>Go to Packages</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: "#faf8f5" }}>
      <Nav />

      <div className="max-w-3xl mx-auto px-5 lg:px-10 pt-28 pb-16">

        {/* Success card */}
        <div className="bg-white rounded-3xl border border-[#A2191B]/10 overflow-hidden shadow-xl mb-6">

          {/* Top banner */}
          <div className="relative overflow-hidden px-8 py-10 text-center" style={{ background: "linear-gradient(135deg,#A2191B 0%,#8B1214 60%,#1a0a0a 100%)" }}>
            <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full opacity-10" style={{ background: "#FCBD70" }} />
            <div className="absolute -bottom-8 -left-8 w-32 h-32 rounded-full opacity-10" style={{ background: "#FA0301" }} />
            <div className="relative z-10">
              <div className="w-16 h-16 rounded-full mx-auto flex items-center justify-center mb-4" style={{ background: "rgba(255,255,255,0.15)", border: "2px solid rgba(255,255,255,0.3)" }}>
                <Check className="w-8 h-8 text-white" strokeWidth={2.5} />
              </div>
              <h1 className="text-3xl font-bold text-white mb-2" style={serif}>Booking Confirmed!</h1>
              <p className="text-white/70 text-sm mb-5" style={sans}>
                A confirmation email has been sent to <span className="text-white font-medium">{order.traveller.email}</span>
              </p>
              <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-5 py-2.5 rounded-full">
                <span className="text-white/60 text-xs" style={mono}>Order ID</span>
                <span className="text-white font-bold" style={mono}>{order.orderId}</span>
              </div>
            </div>
          </div>

          {/* Package summary */}
          <div className="p-6 border-b border-[#A2191B]/8">
            <div className="flex gap-4">
              <div className="w-24 h-20 rounded-xl overflow-hidden shrink-0 bg-[#f5f0eb]">
                <img src={order.packageImage} alt={order.packageTitle} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1">
                <div className="font-bold text-[#1a0a0a] text-lg mb-2" style={serif}>{order.packageTitle}</div>
                <div className="flex flex-wrap gap-3 text-xs text-[#7a5c5c]" style={sans}>
                  <span className="flex items-center gap-1"><MapPin className="w-3 h-3 shrink-0" style={{ color: "#A2191B" }} />{order.places}</span>
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3 shrink-0" style={{ color: "#A2191B" }} />{order.duration}</span>
                  <span className="flex items-center gap-1"><Calendar className="w-3 h-3 shrink-0" style={{ color: "#A2191B" }} />{order.travelDate}</span>
                  <span className="flex items-center gap-1"><Users className="w-3 h-3 shrink-0" style={{ color: "#A2191B" }} />{order.guests} {order.guests === 1 ? "person" : "persons"}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Booking + payment details grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-0 divide-y sm:divide-y-0 sm:divide-x divide-[#A2191B]/8">
            <div className="p-6">
              <div className="text-xs font-semibold uppercase tracking-widest mb-4" style={{ color: "#7a5c5c", ...mono }}>Booking Details</div>
              {[
                { label: "Lead Traveller", value: order.traveller.name },
                { label: "Email", value: order.traveller.email },
                { label: "Phone", value: order.traveller.phone },
                { label: "City", value: order.traveller.city },
                { label: "Booked On", value: formatDate(order.bookedAt) },
              ].map(({ label, value }) => (
                <div key={label} className="flex flex-col mb-3">
                  <span className="text-xs text-[#7a5c5c]" style={sans}>{label}</span>
                  <span className="text-sm font-medium text-[#1a0a0a]" style={sans}>{value}</span>
                </div>
              ))}
            </div>

            <div className="p-6">
              <div className="text-xs font-semibold uppercase tracking-widest mb-4" style={{ color: "#7a5c5c", ...mono }}>Payment Details</div>
              {[
                { label: "Subtotal", value: `₹${order.subtotal.toLocaleString()}` },
                ...(order.discount ? [{ label: "Discount", value: `−₹${order.discount.toLocaleString()}` }] : []),
                { label: "GST (5%)", value: `₹${order.taxes.toLocaleString()}` },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-center mb-3">
                  <span className="text-xs text-[#7a5c5c]" style={sans}>{label}</span>
                  <span className={`text-sm font-medium ${label === "Discount" ? "text-green-600" : "text-[#1a0a0a]"}`} style={sans}>{value}</span>
                </div>
              ))}
              <div className="flex justify-between items-center border-t border-[#A2191B]/10 pt-3 mb-4">
                <span className="text-sm font-bold text-[#1a0a0a]" style={sans}>Total Paid</span>
                <span className="text-xl font-bold" style={{ color: "#A2191B", ...serif }}>₹{order.total.toLocaleString()}</span>
              </div>

              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ background: "#1a7a3c" }} />
                  <span className="text-xs text-[#7a5c5c]" style={sans}>Payment Method: <span className="text-[#1a0a0a] font-medium">{order.paymentMethod}</span></span>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 rounded-full mt-1.5 shrink-0" style={{ background: "#1a7a3c" }} />
                  <span className="text-xs text-[#7a5c5c] break-all" style={sans}>Payment ID: <span className="text-[#1a0a0a] font-medium" style={mono}>{order.paymentId}</span></span>
                </div>
                <div className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-full" style={{ background: "#e6f4ec" }}>
                  <Check className="w-3.5 h-3.5" style={{ color: "#1a7a3c" }} />
                  <span className="text-xs font-semibold" style={{ color: "#1a7a3c", ...sans }}>Payment Successful</span>
                </div>
              </div>
            </div>
          </div>

          {/* Next steps */}
          <div className="p-6 border-t border-[#A2191B]/8" style={{ background: "#faf8f5" }}>
            <div className="text-xs font-semibold uppercase tracking-widest mb-4" style={{ color: "#7a5c5c", ...mono }}>What Happens Next?</div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { step: "01", title: "Email Confirmation", desc: "Booking voucher sent to your email within 15 minutes" },
                { step: "02", title: "Trip Captain Assigned", desc: "Your dedicated trip captain will call you within 24 hours" },
                { step: "03", title: "Pre-Trip Briefing", desc: "Detailed itinerary & hotel vouchers sent 72 hours before departure" },
              ].map(({ step, title, desc }) => (
                <div key={step} className="flex gap-3">
                  <span className="text-xl font-bold shrink-0" style={{ color: "#FCBD70", ...serif }}>{step}</span>
                  <div>
                    <div className="text-sm font-semibold text-[#1a0a0a] mb-1" style={sans}>{title}</div>
                    <div className="text-xs text-[#7a5c5c] leading-relaxed" style={sans}>{desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-col sm:flex-row gap-3 mb-8">
          <button
            onClick={() => navigate("/my-orders")}
            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-white transition-all hover:scale-[1.01]"
            style={{ background: "linear-gradient(135deg,#A2191B,#FA0301)", ...sans }}
          >
            <ShoppingBag className="w-4 h-4" />View My Orders
          </button>
          <button
            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-[#A2191B] border-2 border-[#A2191B]/30 hover:border-[#A2191B] transition-colors"
            style={sans}
          >
            <Download className="w-4 h-4" />Download Voucher
          </button>
          <button
            className="flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl font-semibold text-[#7a5c5c] border-2 border-[#A2191B]/15 hover:border-[#A2191B]/30 transition-colors"
            style={sans}
          >
            <Share2 className="w-4 h-4" />Share
          </button>
        </div>

        {/* Help */}
        <div className="text-center">
          <p className="text-sm text-[#7a5c5c] mb-3" style={sans}>Have questions? We're here to help.</p>
          <div className="flex items-center justify-center gap-6">
            <a href="tel:+911800123456" className="flex items-center gap-2 text-sm font-medium hover:opacity-75 transition-opacity" style={{ color: "#A2191B", ...sans }}>
              <Phone className="w-4 h-4" />1800-123-4567
            </a>
            <a href="mailto:support@bookmyindia.com" className="flex items-center gap-2 text-sm font-medium hover:opacity-75 transition-opacity" style={{ color: "#A2191B", ...sans }}>
              <Mail className="w-4 h-4" />support@bookmyindia.com
            </a>
          </div>
        </div>

      </div>
    </div>
  );
}
