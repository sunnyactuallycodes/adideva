import { useState } from "react";
import { useNavigate } from "react-router";
import {
  Search, MapPin, Calendar, Users, Star, ArrowRight,
  Clock, Heart, Mountain, Waves, Camera, TreePine, Plane,
} from "lucide-react";
import Nav from "../components/Nav";
import Footer from "../components/Footer";
import { packages, type Package } from "../data";

const serif = { fontFamily: "'Playfair Display', serif" };
const sans = { fontFamily: "'DM Sans', sans-serif" };
const mono = { fontFamily: "'DM Mono', monospace" };

const categories = [
  { icon: Mountain, label: "Adventure" },
  { icon: Waves, label: "Beach" },
  { icon: Camera, label: "Heritage" },
  { icon: TreePine, label: "Wildlife" },
  { icon: Plane, label: "Honeymoon" },
];

function PackageCard({ pkg }: { pkg: Package }) {
  const [liked, setLiked] = useState(false);
  const navigate = useNavigate();
  const discount = Math.round(((pkg.originalPrice - pkg.price) / pkg.originalPrice) * 100);

  return (
    <div className="group bg-white rounded-2xl overflow-hidden border border-[#A2191B]/8 hover:shadow-2xl transition-all duration-500 hover:-translate-y-1 flex flex-col cursor-pointer">
      <div className="relative h-52 overflow-hidden bg-[#f5f0eb]" onClick={() => navigate(`/package/${pkg.id}`)}>
        <img src={pkg.image} alt={pkg.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
        <div className="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-semibold text-white" style={{ background: pkg.badgeColor, ...mono }}>
          {pkg.badge}
        </div>
        <div className="absolute top-3 right-12 px-2 py-1 rounded-full text-xs font-bold text-white bg-[#1a7a3c]" style={mono}>
          −{discount}%
        </div>
        <button
          onClick={(e) => { e.stopPropagation(); setLiked(!liked); }}
          className="absolute top-2.5 right-3 w-8 h-8 rounded-full bg-white/90 flex items-center justify-center transition-all hover:scale-110"
        >
          <Heart className="w-4 h-4 transition-colors" fill={liked ? "#FA0301" : "none"} stroke={liked ? "#FA0301" : "#7a5c5c"} strokeWidth={2} />
        </button>
        <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-white" />
          <span className="text-white text-xs font-medium" style={sans}>{pkg.duration}</span>
        </div>
      </div>

      <div className="p-5 flex flex-col flex-1" onClick={() => navigate(`/package/${pkg.id}`)}>
        <h3 className="font-bold text-[#1a0a0a] text-base leading-snug mb-1.5" style={serif}>{pkg.title}</h3>
        <div className="flex items-center gap-1.5 mb-3">
          <MapPin className="w-3.5 h-3.5 shrink-0" style={{ color: "#A2191B" }} />
          <span className="text-xs text-[#7a5c5c]" style={sans}>{pkg.places}</span>
        </div>
        <div className="flex flex-wrap gap-2 mb-4">
          {pkg.highlights.slice(0, 2).map((h) => (
            <span key={h} className="text-xs px-2.5 py-1 rounded-full border border-[#A2191B]/12" style={{ color: "#7a5c5c", background: "#faf8f5", ...sans }}>{h}</span>
          ))}
        </div>
        <div className="flex items-center gap-2 mb-4">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-3.5 h-3.5" fill={i < Math.floor(pkg.rating) ? "#FCBD70" : "none"} stroke="#FCBD70" strokeWidth={1.5} />
            ))}
          </div>
          <span className="text-xs font-semibold text-[#1a0a0a]" style={mono}>{pkg.rating}</span>
          <span className="text-xs text-[#7a5c5c]" style={sans}>({pkg.reviews.toLocaleString()})</span>
        </div>
        <div className="mt-auto flex items-end justify-between">
          <div>
            <div className="text-xs text-[#7a5c5c] line-through" style={sans}>₹{pkg.originalPrice.toLocaleString()}</div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold" style={{ color: "#A2191B", ...serif }}>₹{pkg.price.toLocaleString()}</span>
              <span className="text-xs text-[#7a5c5c]" style={sans}>/person</span>
            </div>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); navigate(`/package/${pkg.id}`); }}
            className="flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-white transition-all hover:scale-105 active:scale-95"
            style={{ background: "linear-gradient(135deg,#A2191B,#FA0301)", ...sans }}
          >
            View
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  const [filter, setFilter] = useState("All");
  const [guests, setGuests] = useState(2);
  const [activeCategory, setActiveCategory] = useState("Heritage");
  const navigate = useNavigate();
  const filters = ["All", "Heritage", "Nature", "Adventure", "Beach", "Cultural"];
  const filtered = filter === "All" ? packages : packages.filter((p) => p.category === filter);

  return (
    <div className="min-h-screen" style={{ background: "#faf8f5" }}>
      <Nav transparent />

      {/* Hero */}
      <section className="relative min-h-[90vh] flex flex-col justify-end overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=1800&h=1100&fit=crop&auto=format"
            alt="Taj Mahal at golden hour"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(26,10,10,0.2) 0%, rgba(26,10,10,0.5) 50%, rgba(26,10,10,0.88) 100%)" }} />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-10 pb-16 pt-36">
          <div className="flex items-center gap-3 mb-5">
            <div className="h-px w-10" style={{ background: "#FCBD70" }} />
            <span className="text-sm font-medium tracking-widest uppercase" style={{ color: "#FCBD70", ...mono }}>Discover Incredible India</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 max-w-3xl" style={{ ...serif, lineHeight: "1.08" }}>
            Every Journey<br /><em className="not-italic" style={{ color: "#FCBD70" }}>Tells a Story.</em>
          </h1>
          <p className="text-white/65 text-lg max-w-lg mb-8" style={{ ...sans, fontWeight: 300 }}>
            Curated holiday packages across India's most breathtaking destinations — handpicked, thoughtfully priced, perfectly timed.
          </p>

          <div className="flex flex-wrap gap-2 mb-8">
            {categories.map(({ icon: Icon, label }) => (
              <button
                key={label}
                onClick={() => setActiveCategory(label)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all border ${activeCategory === label ? "text-white border-transparent" : "text-white/70 border-white/20 bg-white/5 hover:bg-white/10"}`}
                style={{ background: activeCategory === label ? "linear-gradient(135deg,#A2191B,#FA0301)" : undefined, ...sans }}
              >
                <Icon className="w-3.5 h-3.5" />{label}
              </button>
            ))}
          </div>

          {/* Search bar */}
          <div className="bg-white rounded-2xl shadow-2xl p-3 flex flex-col md:flex-row gap-3 max-w-4xl">
            <div className="flex-1 flex items-center gap-3 px-4 py-3 rounded-xl bg-[#faf8f5] border border-[#A2191B]/10">
              <MapPin className="w-5 h-5 shrink-0" style={{ color: "#A2191B" }} />
              <div className="flex-1">
                <div className="text-xs font-semibold uppercase tracking-widest mb-0.5" style={{ color: "#7a5c5c", ...mono }}>Where</div>
                <input placeholder="Search destination..." className="w-full bg-transparent text-sm text-[#1a0a0a] placeholder:text-[#7a5c5c]/50 outline-none" style={sans} />
              </div>
            </div>
            <div className="flex-1 flex items-center gap-3 px-4 py-3 rounded-xl bg-[#faf8f5] border border-[#A2191B]/10">
              <Calendar className="w-5 h-5 shrink-0" style={{ color: "#A2191B" }} />
              <div>
                <div className="text-xs font-semibold uppercase tracking-widest mb-0.5" style={{ color: "#7a5c5c", ...mono }}>When</div>
                <input defaultValue="Oct – Nov 2025" className="w-full bg-transparent text-sm text-[#1a0a0a] outline-none" style={sans} />
              </div>
            </div>
            <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-[#faf8f5] border border-[#A2191B]/10 min-w-[140px]">
              <Users className="w-5 h-5 shrink-0" style={{ color: "#A2191B" }} />
              <div>
                <div className="text-xs font-semibold uppercase tracking-widest mb-0.5" style={{ color: "#7a5c5c", ...mono }}>Guests</div>
                <div className="flex items-center gap-2">
                  <button onClick={() => setGuests(Math.max(1, guests - 1))} className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ background: "#A2191B" }}>−</button>
                  <span className="text-sm font-medium min-w-[20px] text-center" style={sans}>{guests}</span>
                  <button onClick={() => setGuests(guests + 1)} className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ background: "#A2191B" }}>+</button>
                </div>
              </div>
            </div>
            <button className="flex items-center justify-center gap-2 px-8 py-3 rounded-xl font-semibold text-white hover:scale-105 transition-transform" style={{ background: "linear-gradient(135deg,#A2191B,#FA0301)", ...sans, boxShadow: "0 4px 24px rgba(250,3,1,0.3)" }}>
              <Search className="w-4 h-4" />Search
            </button>
          </div>
        </div>
      </section>

      {/* Packages */}
      <section className="py-20 px-5 lg:px-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-5">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <div className="h-px w-7" style={{ background: "#A2191B" }} />
                <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#A2191B", ...mono }}>Handpicked for You</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-[#1a0a0a]" style={{ ...serif, lineHeight: "1.15" }}>
                Featured Packages
              </h2>
            </div>
          </div>
          <div className="flex flex-wrap gap-2 mb-8">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-5 py-2 rounded-full text-sm font-medium transition-all border ${filter === f ? "text-white border-transparent shadow-md" : "text-[#7a5c5c] border-[#A2191B]/20 bg-white hover:border-[#A2191B]/50"}`}
                style={{ background: filter === f ? "linear-gradient(135deg,#A2191B,#FA0301)" : undefined, ...sans }}
              >
                {f}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
            {filtered.map((pkg) => <PackageCard key={pkg.id} pkg={pkg} />)}
          </div>
        </div>
      </section>

      {/* Why us strip */}
      <section className="py-16 px-5 lg:px-10" style={{ background: "#1a0a0a" }}>
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            { val: "10K+", label: "Happy Travellers" },
            { val: "500+", label: "Curated Packages" },
            { val: "200+", label: "Destinations" },
            { val: "4.9★", label: "Average Rating" },
          ].map(({ val, label }) => (
            <div key={label}>
              <div className="text-3xl font-bold mb-1" style={{ color: "#FCBD70", ...serif }}>{val}</div>
              <div className="text-white/50 text-sm" style={sans}>{label}</div>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  );
}
