import { useState } from "react";
import { useNavigate } from "react-router";
import {
  MapPin, Clock, Users, Calendar, Download, ArrowRight,
  Check, X, ChevronDown, ChevronUp, ShoppingBag,
  CreditCard, Phone, Star, Package, TrendingUp, Plane,
  AlertTriangle, RefreshCw,
} from "lucide-react";
import Nav from "../components/Nav";
import Footer from "../components/Footer";
import { useStore } from "../store";
import type { Order } from "../data";

const serif = { fontFamily: "'Playfair Display', serif" };
const sans = { fontFamily: "'DM Sans', sans-serif" };
const mono = { fontFamily: "'DM Mono', monospace" };

type StatusFilter = "all" | "confirmed" | "completed" | "cancelled";

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

function StatusBadge({ status }: { status: Order["status"] }) {
  const map: Record<Order["status"], { label: string; bg: string; text: string; icon: React.ReactNode }> = {
    confirmed: { label: "Upcoming", bg: "#e6f4ec", text: "#1a7a3c", icon: <Check className="w-3 h-3" /> },
    completed: { label: "Completed", bg: "#e8f0ff", text: "#1a5cbf", icon: <Check className="w-3 h-3" /> },
    pending: { label: "Pending", bg: "#fff8e6", text: "#8B6914", icon: <RefreshCw className="w-3 h-3" /> },
    cancelled: { label: "Cancelled", bg: "#fde8e8", text: "#A2191B", icon: <X className="w-3 h-3" /> },
  };
  const s = map[status];
  return (
    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold" style={{ background: s.bg, color: s.text, ...sans }}>
      {s.icon}{s.label}
    </span>
  );
}

function PaymentMethodIcon({ method }: { method: string }) {
  const map: Record<string, string> = {
    "UPI": "📱",
    "Credit Card": "💳",
    "Debit Card": "💳",
    "Net Banking": "🏦",
    "Wallet": "👛",
  };
  return <span className="text-base">{map[method] || "💳"}</span>;
}

function OrderCard({ order }: { order: Order }) {
  const [expanded, setExpanded] = useState(false);
  const navigate = useNavigate();

  const canCancel = order.status === "confirmed";
  const canReview = order.status === "completed";

  return (
    <div className={`bg-white rounded-2xl border overflow-hidden transition-all duration-300 ${expanded ? "border-[#A2191B]/25 shadow-md" : "border-[#A2191B]/10 hover:border-[#A2191B]/20 hover:shadow-sm"}`}>

      {/* Main row */}
      <div className="p-5">
        <div className="flex gap-4">
          {/* Image */}
          <div className="w-20 h-20 rounded-xl overflow-hidden shrink-0 bg-[#f5f0eb] cursor-pointer" onClick={() => navigate(`/package/${order.packageId}`)}>
            <img src={order.packageImage} alt={order.packageTitle} className="w-full h-full object-cover hover:scale-105 transition-transform" />
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-3 mb-1.5">
              <h3 className="font-bold text-[#1a0a0a] text-base leading-snug cursor-pointer hover:text-[#A2191B] transition-colors" style={serif} onClick={() => navigate(`/package/${order.packageId}`)}>
                {order.packageTitle}
              </h3>
              <StatusBadge status={order.status} />
            </div>
            <div className="flex flex-wrap gap-3 text-xs text-[#7a5c5c] mb-3" style={sans}>
              <span className="flex items-center gap-1"><MapPin className="w-3 h-3 shrink-0" style={{ color: "#A2191B" }} />{order.places}</span>
              <span className="flex items-center gap-1"><Clock className="w-3 h-3 shrink-0" style={{ color: "#A2191B" }} />{order.duration}</span>
              <span className="flex items-center gap-1"><Calendar className="w-3 h-3 shrink-0" style={{ color: "#A2191B" }} />{order.travelDate}</span>
              <span className="flex items-center gap-1"><Users className="w-3 h-3 shrink-0" style={{ color: "#A2191B" }} />{order.guests} {order.guests === 1 ? "person" : "persons"}</span>
            </div>
            <div className="flex flex-wrap items-center gap-4">
              <div>
                <span className="text-xs text-[#7a5c5c]" style={sans}>Order ID: </span>
                <span className="text-xs font-bold" style={{ color: "#1a0a0a", ...mono }}>{order.orderId}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <PaymentMethodIcon method={order.paymentMethod} />
                <span className="text-xs text-[#7a5c5c]" style={sans}>{order.paymentMethod}</span>
              </div>
            </div>
          </div>

          {/* Price + actions */}
          <div className="shrink-0 flex flex-col items-end gap-3">
            <div className="text-right">
              <div className="text-xs text-[#7a5c5c] mb-0.5" style={sans}>Total Paid</div>
              <div className="text-xl font-bold" style={{ color: "#A2191B", ...serif }}>₹{order.total.toLocaleString()}</div>
            </div>
            <button
              onClick={() => setExpanded(!expanded)}
              className="flex items-center gap-1.5 text-xs font-medium transition-colors hover:opacity-75"
              style={{ color: "#A2191B", ...sans }}
            >
              {expanded ? <><ChevronUp className="w-3.5 h-3.5" />Less</> : <><ChevronDown className="w-3.5 h-3.5" />Details</>}
            </button>
          </div>
        </div>
      </div>

      {/* Expanded payment details */}
      {expanded && (
        <div className="border-t border-[#A2191B]/8" style={{ background: "#faf8f5" }}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0 divide-y md:divide-y-0 md:divide-x divide-[#A2191B]/8">

            {/* Booking info */}
            <div className="p-5">
              <div className="text-xs font-semibold uppercase tracking-widest mb-4" style={{ color: "#7a5c5c", ...mono }}>Booking Info</div>
              {[
                { label: "Lead Traveller", value: order.traveller.name },
                { label: "Email", value: order.traveller.email },
                { label: "Phone", value: order.traveller.phone },
                { label: "Booked On", value: formatDate(order.bookedAt) },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-center py-1.5 border-b border-[#A2191B]/5 last:border-b-0">
                  <span className="text-xs text-[#7a5c5c]" style={sans}>{label}</span>
                  <span className="text-xs font-medium text-[#1a0a0a] text-right max-w-[180px] truncate" style={sans}>{value}</span>
                </div>
              ))}
            </div>

            {/* Payment breakdown */}
            <div className="p-5">
              <div className="text-xs font-semibold uppercase tracking-widest mb-4" style={{ color: "#7a5c5c", ...mono }}>Payment Breakdown</div>
              {[
                { label: `₹${order.pricePerPerson.toLocaleString()} × ${order.guests}`, value: `₹${order.subtotal.toLocaleString()}` },
                ...(order.discount ? [{ label: "Promo Discount", value: `−₹${order.discount.toLocaleString()}`, green: true }] : []),
                { label: "GST (5%)", value: `₹${order.taxes.toLocaleString()}` },
              ].map(({ label, value, green }: { label: string; value: string; green?: boolean }) => (
                <div key={label} className="flex justify-between items-center py-1.5 border-b border-[#A2191B]/5">
                  <span className="text-xs text-[#7a5c5c]" style={sans}>{label}</span>
                  <span className={`text-xs font-medium ${green ? "text-green-600" : "text-[#1a0a0a]"}`} style={sans}>{value}</span>
                </div>
              ))}
              <div className="flex justify-between items-center py-2 mt-1">
                <span className="text-sm font-bold text-[#1a0a0a]" style={sans}>Total Paid</span>
                <span className="text-base font-bold" style={{ color: "#A2191B", ...serif }}>₹{order.total.toLocaleString()}</span>
              </div>
              <div className="mt-2 flex items-start gap-2">
                <div className="w-2 h-2 rounded-full mt-1 shrink-0" style={{ background: "#1a7a3c" }} />
                <span className="text-xs text-[#7a5c5c] break-all" style={sans}>
                  Payment ID: <span className="font-medium text-[#1a0a0a]" style={mono}>{order.paymentId}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="px-5 py-4 border-t border-[#A2191B]/8 flex flex-wrap gap-3">
            <button
              onClick={() => navigate(`/package/${order.packageId}`)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white transition-all hover:scale-105"
              style={{ background: "linear-gradient(135deg,#A2191B,#FA0301)", ...sans }}
            >
              View Package <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium border border-[#A2191B]/25 text-[#A2191B] hover:border-[#A2191B] transition-colors" style={sans}>
              <Download className="w-3.5 h-3.5" />Download Invoice
            </button>
            {canReview && (
              <button className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium border border-[#FCBD70]/50 text-[#8B6914] hover:bg-[#fff4e6] transition-colors" style={sans}>
                <Star className="w-3.5 h-3.5" />Write Review
              </button>
            )}
            {canCancel && (
              <button className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium text-[#7a5c5c] hover:text-red-600 hover:bg-red-50 transition-colors" style={sans}>
                <X className="w-3.5 h-3.5" />Request Cancellation
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function MyOrders() {
  const { orders } = useStore();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<StatusFilter>("all");

  const filtered = filter === "all" ? orders : orders.filter((o) => o.status === filter);
  const confirmed = orders.filter((o) => o.status === "confirmed").length;
  const completed = orders.filter((o) => o.status === "completed").length;
  const totalSpent = orders.filter((o) => o.status !== "cancelled").reduce((s, o) => s + o.total, 0);

  const filterTabs: { id: StatusFilter; label: string; count: number }[] = [
    { id: "all", label: "All Bookings", count: orders.length },
    { id: "confirmed", label: "Upcoming", count: confirmed },
    { id: "completed", label: "Completed", count: completed },
    { id: "cancelled", label: "Cancelled", count: orders.filter((o) => o.status === "cancelled").length },
  ];

  return (
    <div className="min-h-screen" style={{ background: "#faf8f5" }}>
      <Nav />

      <div className="max-w-5xl mx-auto px-5 lg:px-10 pt-28 pb-16">

        {/* Page header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-5 mb-10">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="h-px w-7" style={{ background: "#A2191B" }} />
              <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#A2191B", ...mono }}>Your Account</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-[#1a0a0a]" style={{ ...serif, lineHeight: "1.1" }}>My Bookings</h1>
            <p className="text-[#7a5c5c] text-sm mt-2" style={sans}>All your travel memories, in one place.</p>
          </div>
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 px-5 py-3 rounded-full text-sm font-semibold text-white transition-all hover:scale-105 self-start"
            style={{ background: "linear-gradient(135deg,#A2191B,#FA0301)", ...sans }}
          >
            <Plane className="w-4 h-4" />Book New Package
          </button>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { icon: Package, label: "Total Bookings", value: String(orders.length), color: "#A2191B" },
            { icon: Plane, label: "Upcoming Trips", value: String(confirmed), color: "#1a5cbf" },
            { icon: Check, label: "Completed", value: String(completed), color: "#1a7a3c" },
            { icon: TrendingUp, label: "Total Spent", value: `₹${(totalSpent / 1000).toFixed(0)}K`, color: "#8B6914" },
          ].map(({ icon: Icon, label, value, color }) => (
            <div key={label} className="bg-white rounded-2xl border border-[#A2191B]/10 p-5 hover:shadow-sm transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: `${color}15` }}>
                  <Icon className="w-5 h-5" style={{ color }} />
                </div>
              </div>
              <div className="text-2xl font-bold mb-0.5" style={{ color, ...serif }}>{value}</div>
              <div className="text-xs text-[#7a5c5c]" style={sans}>{label}</div>
            </div>
          ))}
        </div>

        {/* Filter tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
          {filterTabs.map(({ id, label, count }) => (
            <button
              key={id}
              onClick={() => setFilter(id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-medium shrink-0 transition-all border ${filter === id ? "text-white border-transparent shadow-md" : "text-[#7a5c5c] border-[#A2191B]/20 bg-white hover:border-[#A2191B]/40"}`}
              style={{ background: filter === id ? "linear-gradient(135deg,#A2191B,#FA0301)" : undefined, ...sans }}
            >
              {label}
              <span className={`text-xs px-1.5 py-0.5 rounded-full font-bold ${filter === id ? "bg-white/20 text-white" : "bg-[#A2191B]/10 text-[#A2191B]"}`} style={mono}>{count}</span>
            </button>
          ))}
        </div>

        {/* Orders list */}
        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl border border-[#A2191B]/10 p-12 text-center">
            <div className="w-16 h-16 rounded-full mx-auto flex items-center justify-center mb-4" style={{ background: "#fff4e6" }}>
              <ShoppingBag className="w-8 h-8" style={{ color: "#A2191B" }} />
            </div>
            <h3 className="text-xl font-bold text-[#1a0a0a] mb-2" style={serif}>No orders found</h3>
            <p className="text-sm text-[#7a5c5c] mb-6" style={sans}>You have no {filter !== "all" ? filter : ""} bookings yet.</p>
            <button onClick={() => navigate("/")} className="px-6 py-3 rounded-full text-sm font-semibold text-white" style={{ background: "linear-gradient(135deg,#A2191B,#FA0301)", ...sans }}>
              Explore Packages
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {filtered.map((order) => <OrderCard key={order.orderId} order={order} />)}
          </div>
        )}

        {/* Help section */}
        {orders.length > 0 && (
          <div className="mt-10 bg-white rounded-2xl border border-[#A2191B]/10 p-6">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <h3 className="font-bold text-[#1a0a0a] mb-1" style={serif}>Need Help with a Booking?</h3>
                <p className="text-sm text-[#7a5c5c]" style={sans}>Our travel experts are available 24/7 to assist you.</p>
              </div>
              <div className="flex flex-wrap gap-3">
                <a href="tel:+911800123456" className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium border border-[#A2191B]/25 text-[#A2191B] hover:border-[#A2191B] transition-colors" style={sans}>
                  <Phone className="w-4 h-4" />1800-123-4567
                </a>
                <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-white transition-all hover:scale-105" style={{ background: "linear-gradient(135deg,#A2191B,#FA0301)", ...sans }}>
                  <AlertTriangle className="w-4 h-4" />Raise a Query
                </button>
              </div>
            </div>
          </div>
        )}

      </div>

      <Footer />
    </div>
  );
}
