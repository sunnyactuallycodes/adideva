import { useState } from "react";
import { useLocation, useNavigate } from "react-router";
import {
  MapPin, Clock, Users, Shield, ChevronLeft,
  Check, Tag, Lock, X, Smartphone,
  CreditCard, Building2, Wallet, AlertCircle, Eye, EyeOff,
} from "lucide-react";
import Nav from "../components/Nav";
import { packages, type Order, type RoomSelection, totalGuests } from "../data";
import { useStore } from "../store";

const serif = { fontFamily: "'Playfair Display', serif" };
const sans = { fontFamily: "'DM Sans', sans-serif" };
const mono = { fontFamily: "'DM Mono', monospace" };

// ─── QR Code SVG ─────────────────────────────────────────────────────────────

function QrCode() {
  const cells = [
    [0,0,7,1],[0,1,1,5],[6,1,1,5],[0,6,7,1],[2,2,3,3],
    [14,0,7,1],[14,1,1,5],[20,1,1,5],[14,6,7,1],[16,2,3,3],
    [0,14,7,1],[0,15,1,5],[6,15,1,5],[0,20,7,1],[2,16,3,3],
    [8,0,1,1],[10,0,1,1],[12,0,1,1],[9,2,2,1],[8,3,1,1],[12,3,1,1],
    [9,5,3,1],[8,7,2,1],[11,7,2,1],[0,8,1,1],[2,8,3,1],[6,8,1,1],
    [8,8,1,1],[10,8,1,1],[12,8,1,1],[14,8,1,1],[16,8,1,1],[18,8,1,1],[20,8,1,1],
    [9,10,2,2],[12,9,1,1],[14,10,2,2],[17,9,2,1],[20,10,1,2],
    [8,12,1,2],[10,13,3,1],[14,12,1,1],[16,12,2,1],[19,12,2,2],
    [8,14,4,1],[14,14,3,1],[18,14,1,1],[8,16,1,1],[10,16,2,2],
    [13,16,2,1],[16,16,1,1],[18,16,3,1],[8,18,3,1],[12,18,1,1],
    [14,18,2,1],[17,18,1,2],[19,19,2,1],[8,20,1,1],[10,20,2,1],[13,20,3,1],
  ];
  const px = 8; const size = 21;
  return (
    <svg width={size * px} height={size * px} viewBox={`0 0 ${size * px} ${size * px}`}>
      <rect width="100%" height="100%" fill="white" />
      {cells.map(([x, y, w, h], i) => (
        <rect key={i} x={x * px} y={y * px} width={w * px} height={h * px} fill="#111" />
      ))}
    </svg>
  );
}

// ─── Razorpay Modal ───────────────────────────────────────────────────────────

type RpMethod = "upi" | "card" | "netbanking" | "wallet";

const banks = [
  { id: "hdfc", name: "HDFC Bank", logo: "🏦" }, { id: "sbi", name: "State Bank", logo: "🏛️" },
  { id: "icici", name: "ICICI Bank", logo: "🏦" }, { id: "axis", name: "Axis Bank", logo: "🏦" },
  { id: "kotak", name: "Kotak Mahindra", logo: "💳" }, { id: "yes", name: "Yes Bank", logo: "🏦" },
  { id: "pnb", name: "Punjab National", logo: "🏛️" }, { id: "bob", name: "Bank of Baroda", logo: "🏦" },
];
const wallets = [
  { id: "paytm", name: "Paytm", color: "#00BAF2" }, { id: "phonepe", name: "PhonePe", color: "#5F259F" },
  { id: "amazonpay", name: "Amazon Pay", color: "#FF9900" }, { id: "mobikwik", name: "MobiKwik", color: "#2F3C7E" },
];

function RazorpayModal({ amount, onSuccess, onClose }: { amount: number; onSuccess: (pid: string, method: string) => void; onClose: () => void }) {
  const [method, setMethod] = useState<RpMethod>("upi");
  const [upiMode, setUpiMode] = useState<"qr" | "vpa">("qr");
  const [upiId, setUpiId] = useState("");
  const [upiVerified, setUpiVerified] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [cardNumber, setCardNumber] = useState("");
  const [cardName, setCardName] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");
  const [showCvv, setShowCvv] = useState(false);
  const [selectedBank, setSelectedBank] = useState("");
  const [selectedWallet, setSelectedWallet] = useState("");
  const [payState, setPayState] = useState<"idle" | "processing" | "success">("idle");

  const fmtCard = (v: string) => v.replace(/\D/g, "").slice(0, 16).replace(/(\d{4})(?=\d)/g, "$1 ");
  const fmtExp = (v: string) => { const d = v.replace(/\D/g, "").slice(0, 4); return d.length > 2 ? d.slice(0, 2) + "/" + d.slice(2) : d; };

  const verifyUpi = () => {
    if (!upiId.includes("@")) return;
    setVerifying(true);
    setTimeout(() => { setVerifying(false); setUpiVerified(true); }, 1200);
  };

  const canPay = (): boolean => {
    if (method === "upi") return upiMode === "qr" || upiVerified;
    if (method === "card") return cardNumber.replace(/\s/g, "").length === 16 && cardName.length > 0 && cardExpiry.length === 5 && cardCvv.length >= 3;
    if (method === "netbanking") return selectedBank !== "";
    if (method === "wallet") return selectedWallet !== "";
    return false;
  };

  const handlePay = () => {
    if (!canPay()) return;
    setPayState("processing");
    setTimeout(() => {
      setPayState("success");
      const pid = "pay_" + Math.random().toString(36).slice(2, 18).toUpperCase();
      const label = method === "upi" ? "UPI" : method === "card" ? "Credit Card" : method === "netbanking" ? "Net Banking" : "Wallet";
      setTimeout(() => onSuccess(pid, label), 1400);
    }, 2400);
  };

  const tabs: { id: RpMethod; icon: React.ReactNode; label: string }[] = [
    { id: "upi", icon: <Smartphone className="w-4 h-4" />, label: "UPI" },
    { id: "card", icon: <CreditCard className="w-4 h-4" />, label: "Card" },
    { id: "netbanking", icon: <Building2 className="w-4 h-4" />, label: "Net Banking" },
    { id: "wallet", icon: <Wallet className="w-4 h-4" />, label: "Wallet" },
  ];

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(6px)" }}>
      <div className="w-full max-w-xl bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col" style={{ maxHeight: "92vh" }}>

        {/* Razorpay top bar */}
        <div className="flex items-center gap-3 px-5 py-3.5 shrink-0" style={{ background: "#072654" }}>
          <div className="w-7 h-7 rounded-md bg-white/15 flex items-center justify-center">
            <span className="text-white font-black text-sm">R</span>
          </div>
          <div className="flex-1">
            <div className="text-white text-sm font-semibold" style={sans}>BookMyIndia</div>
            <div className="text-white/50 text-xs" style={sans}>Secured Payment</div>
          </div>
          <div className="text-right">
            <div className="text-white/50 text-xs mb-0.5" style={sans}>Amount</div>
            <div className="text-white font-bold text-lg" style={serif}>₹{amount.toLocaleString()}</div>
          </div>
          <button onClick={onClose} className="ml-3 w-7 h-7 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
            <X className="w-3.5 h-3.5 text-white" />
          </button>
        </div>

        {/* Method tabs */}
        <div className="flex border-b border-gray-100 shrink-0">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => { if (payState === "idle") setMethod(tab.id); }}
              className={`flex-1 flex flex-col items-center gap-1 py-3 text-xs font-medium border-b-2 transition-all ${method === tab.id ? "border-[#072654] text-[#072654]" : "border-transparent text-gray-400 hover:text-gray-600"}`}
              style={sans}
            >
              {tab.icon}{tab.label}
            </button>
          ))}
        </div>

        {/* Content — fixed height + scroll */}
        <div className="overflow-y-auto p-5 flex-1" style={{ scrollbarWidth: "none" }}>

          {payState === "processing" && (
            <div className="flex flex-col items-center justify-center py-14 gap-4">
              <div className="w-14 h-14 rounded-full border-4 border-[#072654]/20 border-t-[#072654] animate-spin" />
              <div className="text-center">
                <div className="font-semibold text-gray-700 mb-1" style={sans}>Processing Payment…</div>
                <div className="text-gray-400 text-sm" style={sans}>Please do not close this window.</div>
              </div>
            </div>
          )}

          {payState === "success" && (
            <div className="flex flex-col items-center justify-center py-14 gap-4">
              <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: "#e6f4ec" }}>
                <Check className="w-8 h-8" style={{ color: "#1a7a3c" }} strokeWidth={2.5} />
              </div>
              <div className="text-center">
                <div className="font-bold text-gray-800 text-lg mb-1" style={serif}>Payment Successful!</div>
                <div className="text-gray-400 text-sm" style={sans}>Redirecting to your confirmation…</div>
              </div>
            </div>
          )}

          {payState === "idle" && method === "upi" && (
            <div>
              <div className="flex p-1 rounded-xl bg-gray-100 mb-5">
                {(["qr", "vpa"] as const).map((m) => (
                  <button key={m} onClick={() => setUpiMode(m)}
                    className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${upiMode === m ? "bg-white shadow text-[#072654]" : "text-gray-400"}`}
                    style={sans}>
                    {m === "qr" ? "📷  Scan QR Code" : "⌨️  Enter UPI ID"}
                  </button>
                ))}
              </div>

              {upiMode === "qr" ? (
                <div className="flex flex-col items-center gap-4">
                  <div className="p-3 rounded-2xl border-2 border-gray-100"><QrCode /></div>
                  <div className="text-center">
                    <div className="font-semibold text-gray-700 text-sm mb-1" style={sans}>Scan with any UPI app</div>
                    <div className="text-gray-400 text-xs" style={sans}>Google Pay · PhonePe · Paytm · BHIM</div>
                  </div>
                  <div className="text-xs font-medium text-[#072654] bg-blue-50 px-3 py-2 rounded-lg" style={mono}>bookmyindia@razorpay</div>
                </div>
              ) : (
                <div>
                  <label className="text-xs font-semibold uppercase tracking-widest block mb-2" style={{ color: "#7a5c5c", ...mono }}>UPI ID / VPA</label>
                  <div className="flex gap-2">
                    <div className={`flex-1 flex items-center gap-2 px-4 py-3 rounded-xl border-2 transition-colors ${upiVerified ? "border-green-400 bg-green-50" : "border-gray-200 focus-within:border-[#072654]"}`}>
                      <Smartphone className="w-4 h-4 text-gray-400 shrink-0" />
                      <input value={upiId} onChange={(e) => { setUpiId(e.target.value); setUpiVerified(false); }}
                        placeholder="yourname@upi" className="flex-1 outline-none text-sm text-gray-700 bg-transparent" style={sans}
                        onKeyDown={(e) => e.key === "Enter" && verifyUpi()} />
                      {upiVerified && <Check className="w-4 h-4 text-green-500 shrink-0" />}
                    </div>
                    <button onClick={verifyUpi} disabled={!upiId.includes("@") || verifying || upiVerified}
                      className="px-4 py-3 rounded-xl text-sm font-semibold text-white transition-all disabled:opacity-40"
                      style={{ background: "#072654", ...sans }}>
                      {verifying ? "…" : "Verify"}
                    </button>
                  </div>
                  {upiVerified && <div className="flex items-center gap-2 mt-2 text-green-600 text-xs" style={sans}><Check className="w-3.5 h-3.5" />UPI ID verified</div>}
                </div>
              )}
            </div>
          )}

          {payState === "idle" && method === "card" && (
            <div className="flex flex-col gap-4">
              {/* Live card preview */}
              <div className="rounded-xl p-5 text-white relative overflow-hidden h-[140px]" style={{ background: "linear-gradient(135deg,#A2191B,#4a0a0a)" }}>
                <div className="text-[10px] opacity-50 mb-2 tracking-widest" style={mono}>CARD NUMBER</div>
                <div className="text-base font-mono tracking-widest mb-4">{cardNumber || "•••• •••• •••• ••••"}</div>
                <div className="flex items-end justify-between">
                  <div><div className="text-[10px] opacity-50 tracking-widest mb-0.5" style={mono}>CARDHOLDER</div><div className="text-sm font-medium">{cardName || "YOUR NAME"}</div></div>
                  <div><div className="text-[10px] opacity-50 tracking-widest mb-0.5" style={mono}>EXPIRES</div><div className="text-sm font-medium">{cardExpiry || "MM/YY"}</div></div>
                </div>
                <div className="absolute top-4 right-5 text-3xl font-black opacity-15" style={serif}>VISA</div>
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-500 block mb-1.5" style={mono}>CARD NUMBER</label>
                <input value={cardNumber} onChange={(e) => setCardNumber(fmtCard(e.target.value))} placeholder="1234 5678 9012 3456" maxLength={19}
                  className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#072654] transition-colors" style={sans} />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-500 block mb-1.5" style={mono}>NAME ON CARD</label>
                <input value={cardName} onChange={(e) => setCardName(e.target.value)} placeholder="Priya Sharma"
                  className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#072654] transition-colors" style={sans} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-gray-500 block mb-1.5" style={mono}>EXPIRY</label>
                  <input value={cardExpiry} onChange={(e) => setCardExpiry(fmtExp(e.target.value))} placeholder="MM/YY" maxLength={5}
                    className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#072654] transition-colors" style={sans} />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-500 block mb-1.5" style={mono}>CVV</label>
                  <div className="relative">
                    <input value={cardCvv} onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, "").slice(0, 4))} placeholder="•••" type={showCvv ? "text" : "password"}
                      className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#072654] transition-colors pr-10" style={sans} />
                    <button type="button" onClick={() => setShowCvv(!showCvv)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                      {showCvv ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {payState === "idle" && method === "netbanking" && (
            <div>
              <label className="text-xs font-semibold text-gray-500 block mb-3" style={mono}>SELECT YOUR BANK</label>
              <div className="grid grid-cols-2 gap-2">
                {banks.map((bank) => (
                  <button key={bank.id} onClick={() => setSelectedBank(bank.id)}
                    className={`flex items-center gap-2.5 p-3.5 rounded-xl border-2 text-left transition-all ${selectedBank === bank.id ? "border-[#072654] bg-blue-50" : "border-gray-200 hover:border-gray-300"}`}>
                    <span className="text-xl">{bank.logo}</span>
                    <span className="text-xs font-medium text-gray-700" style={sans}>{bank.name}</span>
                    {selectedBank === bank.id && <Check className="w-3.5 h-3.5 ml-auto text-[#072654]" />}
                  </button>
                ))}
              </div>
            </div>
          )}

          {payState === "idle" && method === "wallet" && (
            <div>
              <label className="text-xs font-semibold text-gray-500 block mb-3" style={mono}>SELECT WALLET</label>
              <div className="flex flex-col gap-2.5">
                {wallets.map((w) => (
                  <button key={w.id} onClick={() => setSelectedWallet(w.id)}
                    className={`flex items-center gap-3 p-4 rounded-xl border-2 transition-all ${selectedWallet === w.id ? "border-[#072654] bg-blue-50" : "border-gray-200 hover:border-gray-300"}`}>
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: w.color }}>
                      <Wallet className="w-4 h-4 text-white" />
                    </div>
                    <span className="font-medium text-gray-700 text-sm" style={sans}>{w.name}</span>
                    {selectedWallet === w.id && <Check className="w-4 h-4 ml-auto text-[#072654]" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Pay button footer */}
        {payState === "idle" && (
          <div className="px-5 pb-5 pt-3 border-t border-gray-100 shrink-0">
            <button
              onClick={handlePay}
              disabled={!canPay()}
              className="w-full py-4 rounded-xl font-bold text-white text-base transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90"
              style={{ background: canPay() ? "#072654" : "#9ca3af", ...sans }}
            >
              Pay ₹{amount.toLocaleString()}
            </button>
            <div className="flex items-center justify-center gap-1.5 mt-2">
              <Lock className="w-3 h-3 text-gray-400" />
              <span className="text-xs text-gray-400" style={sans}>256-bit SSL · Secured by Razorpay</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Checkout page ────────────────────────────────────────────────────────────

interface CheckoutState {
  packageId: number;
  travelDate: string;
  guests: number;
  rooms?: RoomSelection;
  pricePerPerson: number;
}

interface TravellerForm { name: string; email: string; phone: string; city: string; requests: string; }

export default function Checkout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { addOrder, packages: storePkgs } = useStore();

  const state: CheckoutState = (location.state as CheckoutState | null) || {
    packageId: 1, travelDate: "15 Oct 2025", guests: 2,
    rooms: { double: 1, triple: 0, quad: 0 }, pricePerPerson: 24999,
  };

  const allPkgs = storePkgs.length ? storePkgs : packages;
  const pkg = allPkgs.find((p) => p.id === state.packageId) || allPkgs[0];

  const [form, setForm] = useState<TravellerForm>({ name: "", email: "", phone: "", city: "", requests: "" });
  const [errors, setErrors] = useState<Partial<TravellerForm>>({});
  const [promoCode, setPromoCode] = useState("");
  const [promoApplied, setPromoApplied] = useState(false);
  const [promoError, setPromoError] = useState("");
  const [showRazorpay, setShowRazorpay] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const subtotal = state.pricePerPerson * state.guests;
  const discount = promoApplied ? Math.round(subtotal * 0.15) : 0;
  const taxable = subtotal - discount;
  const taxes = Math.round(taxable * 0.05);
  const total = taxable + taxes;

  const applyPromo = () => {
    if (promoCode.trim().toUpperCase() === "FIRST15") {
      setPromoApplied(true); setPromoError("");
    } else {
      setPromoError("Invalid code. Try FIRST15 for 15% off."); setPromoApplied(false);
    }
  };

  const validate = () => {
    const e: Partial<TravellerForm> = {};
    if (!form.name.trim()) e.name = "Full name is required";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Enter a valid email";
    if (!/^[6-9]\d{9}$/.test(form.phone.replace(/\s/g, ""))) e.phone = "Enter a valid 10-digit mobile number";
    if (!form.city.trim()) e.city = "City is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleProceed = () => {
    if (!validate() || !agreedToTerms) return;
    setShowRazorpay(true);
  };

  const handlePaymentSuccess = (paymentId: string, method: string) => {
    const order: Order = {
      orderId: `BMI-2025-${String(Math.floor(1000 + Math.random() * 9000))}`,
      packageId: pkg.id, packageTitle: pkg.title,
      packageImage: pkg.image, places: pkg.places, duration: pkg.duration,
      travelDate: state.travelDate, guests: state.guests,
      rooms: state.rooms,
      pricePerPerson: state.pricePerPerson,
      discount, subtotal, taxes, total,
      paymentMethod: method, paymentId,
      status: "confirmed",
      bookedAt: new Date().toISOString(),
      traveller: { name: form.name, email: form.email, phone: form.phone, city: form.city },
    };
    addOrder(order);
    setShowRazorpay(false);
    navigate("/order-success", { state: { order } });
  };

  const Field = ({ k, label, placeholder, type = "text" }: { k: keyof TravellerForm; label: string; placeholder: string; type?: string }) => (
    <div>
      <label className="text-xs font-semibold uppercase tracking-widest block mb-1.5" style={{ color: "#7a5c5c", ...mono }}>{label}</label>
      <input type={type} value={form[k]} onChange={(e) => { setForm({ ...form, [k]: e.target.value }); setErrors({ ...errors, [k]: "" }); }}
        placeholder={placeholder}
        className={`w-full border-2 rounded-xl px-4 py-3 text-sm outline-none transition-colors ${errors[k] ? "border-red-400 bg-red-50" : "border-[#A2191B]/15 focus:border-[#A2191B]"}`}
        style={sans} />
      {errors[k] && <div className="flex items-center gap-1.5 mt-1.5 text-red-500 text-xs" style={sans}><AlertCircle className="w-3.5 h-3.5 shrink-0" />{errors[k]}</div>}
    </div>
  );

  return (
    <div className="min-h-screen" style={{ background: "#faf8f5" }}>
      <Nav />
      {showRazorpay && <RazorpayModal amount={total} onSuccess={handlePaymentSuccess} onClose={() => setShowRazorpay(false)} />}

      <div className="max-w-6xl mx-auto px-5 lg:px-10 pt-24 pb-16">
        <button onClick={() => navigate(`/package/${pkg.id}`)} className="flex items-center gap-2 text-sm text-[#7a5c5c] hover:text-[#A2191B] transition-colors mb-6" style={sans}>
          <ChevronLeft className="w-4 h-4" />Back to Package
        </button>

        <div className="flex items-center gap-3 mb-2">
          <div className="h-px w-7" style={{ background: "#A2191B" }} />
          <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#A2191B", ...mono }}>Secure Checkout</span>
        </div>
        <h1 className="text-4xl font-bold text-[#1a0a0a] mb-8" style={{ ...serif, lineHeight: "1.2" }}>Complete Your Booking</h1>

        {/* Progress */}
        <div className="flex items-center gap-3 mb-10">
          {["Trip Details", "Traveller Info", "Payment"].map((step, i) => (
            <div key={step} className="flex items-center gap-2">
              <div className="flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold" style={{ background: i <= 1 ? (i === 0 ? "#1a7a3c" : "#A2191B") : "#f5f0eb", color: i <= 1 ? "white" : "#7a5c5c", ...mono }}>
                {i === 0 ? <Check className="w-3.5 h-3.5" /> : i + 1}
              </div>
              <span className={`text-sm font-medium hidden sm:block ${i === 1 ? "text-[#A2191B]" : i === 0 ? "text-[#1a7a3c]" : "text-[#7a5c5c]"}`} style={sans}>{step}</span>
              {i < 2 && <div className="w-4 h-px bg-[#A2191B]/20 mx-1" />}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-start">
          {/* Left: form */}
          <div className="lg:col-span-3 flex flex-col gap-6">

            {/* Trip summary */}
            <div className="bg-white rounded-2xl border border-[#A2191B]/10 p-5">
              <h3 className="font-bold text-[#1a0a0a] mb-4" style={serif}>Your Trip</h3>
              <div className="flex gap-4">
                <div className="w-24 h-20 rounded-xl overflow-hidden shrink-0 bg-[#f5f0eb]">
                  <img src={pkg.image} alt={pkg.title} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1">
                  <div className="font-bold text-[#1a0a0a] mb-2" style={serif}>{pkg.title}</div>
                  <div className="flex flex-wrap gap-3 text-xs text-[#7a5c5c]" style={sans}>
                    <span className="flex items-center gap-1"><MapPin className="w-3 h-3 shrink-0" style={{ color: "#A2191B" }} />{pkg.places}</span>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3 shrink-0" style={{ color: "#A2191B" }} />{pkg.duration}</span>
                    <span className="flex items-center gap-1"><Users className="w-3 h-3 shrink-0" style={{ color: "#A2191B" }} />{state.guests} guests</span>
                  </div>
                  {state.rooms && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {state.rooms.double > 0 && <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "#fff4e6", color: "#A2191B", ...sans }}>{state.rooms.double}× Double</span>}
                      {state.rooms.triple > 0 && <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "#fef3c7", color: "#8B6914", ...sans }}>{state.rooms.triple}× Triple</span>}
                      {state.rooms.quad > 0 && <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "#dbeafe", color: "#1a5c8a", ...sans }}>{state.rooms.quad}× Quad</span>}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Traveller details */}
            <div className="bg-white rounded-2xl border border-[#A2191B]/10 p-5">
              <h3 className="font-bold text-[#1a0a0a] mb-5" style={serif}>Lead Traveller Details</h3>
              <div className="flex flex-col gap-4">
                <Field k="name" label="Full Name" placeholder="Priya Sharma" />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Field k="email" label="Email Address" placeholder="priya@example.com" type="email" />
                  <Field k="phone" label="Mobile Number" placeholder="98765 43210" type="tel" />
                </div>
                <Field k="city" label="Your City" placeholder="Mumbai" />
                <div>
                  <label className="text-xs font-semibold uppercase tracking-widest block mb-1.5" style={{ color: "#7a5c5c", ...mono }}>Special Requests (optional)</label>
                  <textarea value={form.requests} onChange={(e) => setForm({ ...form, requests: e.target.value })}
                    placeholder="Dietary preferences, room type, accessibility needs…" rows={3}
                    className="w-full border-2 border-[#A2191B]/15 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#A2191B] transition-colors resize-none" style={sans} />
                </div>
              </div>
            </div>

            {/* Payment */}
            <div className="bg-white rounded-2xl border border-[#A2191B]/10 p-5">
              <h3 className="font-bold text-[#1a0a0a] mb-4" style={serif}>Payment</h3>

              {/* Razorpay option */}
              <div className="flex items-center gap-3 p-4 rounded-xl border-2 border-[#072654]/20 bg-blue-50/40 mb-4">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: "#072654" }}>
                  <span className="text-white font-black text-base">R</span>
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-gray-800 text-sm" style={sans}>Pay with Razorpay</div>
                  <div className="text-xs text-gray-500" style={sans}>UPI · Cards · Net Banking · Wallets · EMI</div>
                </div>
                <div className="flex gap-1.5">
                  {["UPI", "VISA", "MC"].map((m) => (
                    <span key={m} className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-white border border-gray-200 text-gray-600" style={mono}>{m}</span>
                  ))}
                </div>
              </div>

              {/* T&C checkbox */}
              <button onClick={() => setAgreedToTerms(!agreedToTerms)} className="flex items-start gap-3 mb-5 text-left w-full">
                <div className={`w-5 h-5 rounded border-2 shrink-0 mt-0.5 flex items-center justify-center transition-all ${agreedToTerms ? "border-[#A2191B]" : "border-gray-300"}`}
                  style={{ background: agreedToTerms ? "#A2191B" : "white" }}>
                  {agreedToTerms && <Check className="w-3 h-3 text-white" strokeWidth={3} />}
                </div>
                <span className="text-xs text-[#7a5c5c] leading-relaxed" style={sans}>
                  I have read and agree to BookMyIndia's{" "}
                  <span className="underline" style={{ color: "#A2191B" }}>Terms & Conditions</span>,{" "}
                  <span className="underline" style={{ color: "#A2191B" }}>Privacy Policy</span>, and{" "}
                  <span className="underline" style={{ color: "#A2191B" }}>Cancellation Policy</span>.
                </span>
              </button>

              {!agreedToTerms && (
                <div className="flex items-center gap-2 text-xs text-amber-600 mb-4 p-3 rounded-lg" style={{ background: "#fffbf0", ...sans }}>
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />Please agree to the terms to proceed.
                </div>
              )}

              <button
                onClick={handleProceed}
                className="w-full py-4 rounded-xl font-bold text-white text-base transition-all hover:scale-[1.01] active:scale-[0.99] shadow-lg"
                style={{ background: agreedToTerms ? "linear-gradient(135deg,#A2191B,#FA0301)" : "#d1d5db", ...sans, boxShadow: agreedToTerms ? "0 6px 24px rgba(250,3,1,0.28)" : "none", cursor: agreedToTerms ? "pointer" : "not-allowed" }}
              >
                Proceed to Pay ₹{total.toLocaleString()} →
              </button>

              <div className="flex items-center justify-center gap-1.5 mt-3">
                <Shield className="w-3.5 h-3.5 text-[#1a7a3c]" />
                <span className="text-xs text-[#7a5c5c]" style={sans}>100% secure · Instant confirmation · Free cancellation (30 days)</span>
              </div>
            </div>
          </div>

          {/* Right: order summary */}
          <div className="lg:col-span-2">
            <div className="sticky top-24 bg-white rounded-2xl border border-[#A2191B]/12 shadow-lg overflow-hidden">
              <div className="px-5 py-4 border-b border-[#A2191B]/8" style={{ background: "linear-gradient(135deg,#fdf5f0,#fff4e6)" }}>
                <h3 className="font-bold text-[#1a0a0a]" style={serif}>Order Summary</h3>
              </div>
              <div className="p-5">
                {/* Promo */}
                <div className="mb-5">
                  <label className="text-xs font-semibold uppercase tracking-widest block mb-2" style={{ color: "#7a5c5c", ...mono }}>Promo Code</label>
                  {promoApplied ? (
                    <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-xl px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <Tag className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-semibold text-green-700" style={mono}>FIRST15</span>
                        <span className="text-xs text-green-600" style={sans}>15% applied!</span>
                      </div>
                      <button onClick={() => { setPromoApplied(false); setPromoCode(""); }}><X className="w-4 h-4 text-green-600" /></button>
                    </div>
                  ) : (
                    <>
                      <div className="flex gap-2">
                        <input value={promoCode} onChange={(e) => { setPromoCode(e.target.value.toUpperCase()); setPromoError(""); }}
                          placeholder="e.g. FIRST15" onKeyDown={(e) => e.key === "Enter" && applyPromo()}
                          className="flex-1 border-2 border-[#A2191B]/15 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-[#A2191B] uppercase" style={{ ...mono, letterSpacing: "0.08em" }} />
                        <button onClick={applyPromo} className="px-4 py-2.5 rounded-xl text-sm font-semibold text-white hover:scale-105 transition-transform" style={{ background: "#A2191B", ...sans }}>Apply</button>
                      </div>
                      {promoError && <div className="text-xs text-red-500 mt-1.5" style={sans}>{promoError}</div>}
                    </>
                  )}
                </div>

                {/* Breakdown */}
                <div className="flex flex-col gap-2.5 text-sm" style={sans}>
                  <div className="flex justify-between">
                    <span className="text-[#7a5c5c]">₹{state.pricePerPerson.toLocaleString()} × {state.guests} guests</span>
                    <span className="font-medium text-[#1a0a0a]">₹{subtotal.toLocaleString()}</span>
                  </div>
                  {promoApplied && (
                    <div className="flex justify-between text-green-600">
                      <span>Promo discount (15%)</span>
                      <span className="font-medium">−₹{discount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-[#7a5c5c]">GST (5%)</span>
                    <span className="font-medium text-[#1a0a0a]">₹{taxes.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between border-t border-[#A2191B]/10 pt-2.5 font-bold">
                    <span className="text-[#1a0a0a]">Total Payable</span>
                    <span style={{ color: "#A2191B", ...serif, fontSize: "20px" }}>₹{total.toLocaleString()}</span>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-[#A2191B]/8">
                  <div className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "#7a5c5c", ...mono }}>Included</div>
                  {["6-night 5-star stays", "All meals as per plan", "Private AC transport", "Expert guides & entry fees"].map((item) => (
                    <div key={item} className="flex items-center gap-2 mb-2">
                      <Check className="w-3.5 h-3.5 shrink-0" style={{ color: "#1a7a3c" }} strokeWidth={2.5} />
                      <span className="text-xs text-[#3a2a2a]" style={sans}>{item}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-5 pt-4 border-t border-[#A2191B]/8 grid grid-cols-3 gap-3 text-center">
                  {[{ icon: Shield, label: "Secure\nPayment" }, { icon: Check, label: "Instant\nConfirmation" }, { icon: Clock, label: "Free Cancel\n30 Days" }].map(({ icon: Icon, label }) => (
                    <div key={label}>
                      <div className="w-8 h-8 rounded-lg mx-auto flex items-center justify-center mb-1" style={{ background: "#fff4e6" }}>
                        <Icon className="w-4 h-4" style={{ color: "#A2191B" }} />
                      </div>
                      <div className="text-[10px] text-[#7a5c5c] leading-tight whitespace-pre-line" style={sans}>{label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
